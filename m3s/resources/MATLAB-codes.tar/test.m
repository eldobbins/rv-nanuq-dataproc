%   Program:  test.m
%     Developed by: Shawn R. Smith and Mark A. Bourassa
%   Programmed by: Arturo Valery
%   Purpose:  testing of program truew.m
%      Updated:  October 31, 2014
%     
%     Direct questions to:  wocemet@coaps.fsu.edu 
%      
%     DESCRIPTION
%     ***********
%     
%     The following source code enables the user to test the truewind.c
%     program using sixteen examples:
%     --Examples #1-10 contain no missing values, and all values
%       are valid.  "tdir" and "tspd" are calculated.  
%     --Example #11 contains one missing value.  "tdir" and "tspd" are
%       NOT calculated and are given the values of the missing value
%       flag.
%     --Example #12 contains all missing values.  "tdir" and "tspd" are
%       NOT calculated and are given the values of the missing value
%       flag.  
%     --Examples #13-17 each contain one invalid value.  "tdir" and "tspd"
%       are NOT calculated and are given the values of the missing value
%       flag.
%       
%     Descriptions of the variable names can be found in the source code
%     of "truewind.c".
%     
%     The output should be the similar to the text file "results".
%     
%     Because this data set is relatively small, the full test is run
%     (sel = 1) to show all possible types of output.
%  
%     


function [] = test()

  crse = [0.0, 0.0, 0.0, 0.0, 180.0, 90.0, 90.0, 225.0, 270.0, 0.0, 2.0, -1111.0, -2.0, 3.0, 0.0, 0.0, 5.0];
  cspd = [0.0, 0.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 3.0, 0.0, -9999.0, -9999.0, 8.0, -6.0, 0.0, 0.0, 1.0];
  wdir= [90.0, 90.0, 0.0, 0.0, 180.0, 90.0, 135.0, 270.0, 90.0, 0.0, 0.0, 1111.0, 8.0, 0.0, -9.0, 7.0, 2.0];
  hd = [0.0, 90.0, 0.0, 0.0, 180.0, 90.0, 45.0, 225.0, 270.0,  0.0, 0.0, 5555.0, 8.0, 8.0, 8.0, 8.0, -13.0];
  wspd = [5.0, 5.0, 5.0, 0.0, 5.0, 5.0, 5.0, 5.0, 4.0, 0.0, 0.0, 9999.0, 3.0, 3.0, 3.0, -4.0, 2.0];
  adir = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0];
  wmis = [-1111.0, -9999.0, 1111.0, 9999.0, 5555.0];
  zlr = 0.0;
  num = 17;
  sel = 1;
  tdir = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
  tspd = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
  nw = 0;
  nwam = 0;
  nwpm = 0;
  nwf = 0;
  
  
  truew(num, sel, crse, cspd, wdir, zlr, hd, adir, wspd, ...
    wmis, tdir, tspd, nw, nwam, nwpm, nwf);

end

